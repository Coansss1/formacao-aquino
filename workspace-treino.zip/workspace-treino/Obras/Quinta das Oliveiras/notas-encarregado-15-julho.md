# Notas do encarregado — 15 julho 2026 (Quinta das Oliveiras)

*(notas rápidas tiradas no telemóvel durante o dia — é isto que o skill relatorio-obra transforma em relatório formal)*

manhã: betonagem piso 1 zona B, correu bem, acabou 12h30
2 gruas + betoneira da Silva & Filhos
18 homens hoje (3 da subempreitada Ferrolho para as armaduras)
tarde: cofragem piso 1 zona C começou
problema: camião de betão da 2a carga chegou com 40min de atraso, Betão Centro outra vez
eletricista passou cá, diz que precisa das esperas na zona B confirmadas até 6a feira senão atrasa
tempo: sol, 31 graus, parou-se 30 min à tarde por causa do calor (regra QAS acima dos 30)
visita do dono de obra marcada para dia 17 às 10h
falta: guia de transporte da carga 2 do betão, pedir à Betão Centro
amanhã: continuar cofragem zona C, betonagem zona C prevista para dia 17 de manhã antes da visita
