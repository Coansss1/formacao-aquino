---
name: compara-cotacoes
description: Compara cotações de fornecedores e recomenda a melhor opção considerando preço, prazos, condições e risco. Usar quando se pedem comparações de cotações, propostas de fornecedores ou decisões de compra.
---

# Comparação de Cotações

Transforma emails de fornecedores numa decisão de compra fundamentada.

## Como fazer
1. Ler as cotações (normalmente em `Compras/`, coladas tal como chegaram por email)
2. Normalizar tudo para valores comparáveis — atenção a custos escondidos (transporte, bombagem, mínimos, descontos condicionais)
3. Produzir a comparação e guardar em `Compras/comparacao-<assunto>-<data>.md`

## Estrutura obrigatória
```
# Comparação de Cotações — <assunto>

## 1. Tabela comparativa
| | Fornecedor A | Fornecedor B | Fornecedor C |
(preço unitário real com todos os custos incluídos · condições de pagamento ·
prazo de fornecimento · riscos/limitações · custo total estimado para a necessidade real)

## 2. Custo total estimado para o nosso caso concreto (mostrar as contas)
## 3. Riscos não-preço (fiabilidade, paragens, capacidade, histórico connosco)
## 4. RECOMENDAÇÃO — fornecedor escolhido e porquê; plano B se existir motivo
```

## Regras
- O preço por unidade anunciado raramente é o preço real — calcular sempre o custo total para o caso concreto
- O histórico de fiabilidade vale tanto como o preço (um fornecedor barato que atrasa betonagens custa caro)
- Mostrar as contas — a tabela tem de ser verificável por um engenheiro em 2 minutos
- Se faltar informação para comparar bem, listar as perguntas a fazer a cada fornecedor
