---
name: verifica-auto
description: Verifica um auto de medição contra o orçamento contratado — quantidades acima do contratado, artigos não contratados, preços unitários divergentes e erros de cálculo. Usar quando se pede para verificar, conferir ou validar um auto de medição.
---

# Verificação de Auto de Medição

Confere o auto de medição mensal contra o mapa de quantidades contratado, antes de o submeter ou aprovar.

## Como fazer
1. Ler o orçamento (`orcamento-contratado.csv`) e o auto do mês (`auto-medicao-*.csv`) na pasta da obra
2. Verificar, artigo a artigo:
   - **Quantidades:** acumulado ≤ quantidade contratada? Acima de 100% = trabalhos a mais, exigem aprovação formal (CCP)
   - **Artigos:** todos os artigos do auto existem no contrato? Artigos novos sem contrato = sinalizar
   - **Preços unitários:** iguais aos contratados? Qualquer divergência = sinalizar
   - **Aritmética:** quantidade × preço unitário = valor? Somas dos totais corretas?
3. Produzir o relatório e guardar em `<pasta da obra>/verificacao-auto-<mês>.md`

## Estrutura do relatório
```
# Verificação de Auto — <obra>, <mês>

## Resultado: ✅ Sem problemas / ⚠️ X problemas encontrados

## Problemas (por gravidade)
| # | Artigo | Problema | Impacto (€) | Ação recomendada |

## Execução da empreitada
- Valor acumulado vs. contratado (% de execução)
- Capítulos com maior desvio

## Conclusão em 2 frases
```

## Regras
- Mostrar sempre as contas de cada problema encontrado — tem de ser verificável em 2 minutos
- Distinguir claramente: erro de cálculo (corrigir) vs. trabalho a mais (processo formal CCP) vs. divergência de preço (esclarecer com a fiscalização)
- Nunca aprovar nem reprovar — a decisão é humana; o skill prepara a decisão
