---
name: ata-reuniao
description: Transforma notas soltas de uma reunião numa ata formal com decisões, ações, responsáveis e prazos. Usar quando se pedem atas ou se partilham notas de reunião.
---

# Ata de Reunião

Transforma notas rápidas numa ata que ninguém precisa de reescrever.

## Como fazer
1. Ler as notas (normalmente em `Reunioes/`)
2. Produzir a ata e guardar em `Reunioes/ata-<data>.md`

## Estrutura obrigatória
```
# Ata — <tipo de reunião>
**Data:** · **Presentes:** · **Próxima reunião:**

## 1. Assuntos tratados (por tema, 1-3 frases cada)
## 2. Decisões tomadas
## 3. Ações
| Ação | Responsável | Prazo |
## 4. Pontos em aberto (sem decisão — a retomar)
```

## Regras
- Uma ação sem responsável não é uma ação — se as notas não disserem quem faz, colocar "POR ATRIBUIR" em destaque
- Prazos vagos ("esta semana") são convertidos em datas concretas quando o contexto permite
- Assuntos urgentes ou com custo (multas, juros, prazos legais) ficam no topo da lista de ações
- Manter os nomes exatamente como estão nas notas
