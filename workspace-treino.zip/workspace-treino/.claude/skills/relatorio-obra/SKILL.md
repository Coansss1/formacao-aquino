---
name: relatorio-obra
description: Transforma as notas rápidas do encarregado num relatório diário de obra formal. Usar quando alguém pede um relatório de obra ou partilha notas de um dia de obra.
---

# Relatório Diário de Obra

Transforma notas informais (telemóvel, papel, ditadas) num relatório formal.

## Como fazer
1. Ler as notas do dia (normalmente em `Obras/<nome da obra>/diario-obra-<data>.md`)
2. Produzir o relatório com a estrutura abaixo
3. Guardar em `Obras/<nome da obra>/relatorios/relatorio-<data>.md`
4. Assinalar em destaque tudo o que precisa de ação (documentos em falta, prazos, pendências)

## Estrutura obrigatória
```
# Relatório Diário de Obra — <Obra>
**Data:** · **Elaborado por:** · **Condições meteorológicas:**

## 1. Trabalhos realizados
## 2. Mão-de-obra (própria + subempreitadas, com totais)
## 3. Equipamentos em obra
## 4. Ocorrências e desvios
## 5. Pendências e ações necessárias (com responsável e prazo)
## 6. Trabalhos previstos para o dia seguinte
```

## Regras
- Linguagem técnica e objetiva, português europeu
- Nunca inventar dados — o que não estiver nas notas fica como "não registado"
- Ocorrências com impacto no prazo ou custo ficam sempre na secção 4, mesmo que pareçam pequenas
- Paragens por razões de segurança (QAS) são sempre registadas
