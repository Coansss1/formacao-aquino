---
name: analise-concurso
description: Analisa um caderno de encargos de concurso público e produz uma recomendação go/no-go fundamentada. Usar quando se pede análise de um concurso, caderno de encargos ou decisão de concorrer.
---

# Análise de Concurso Público

Apoia a decisão de concorrer ou não a um concurso público.

## Como fazer
1. Ler o resumo do caderno de encargos em `Concursos/<nome>/`
2. Produzir a análise com a estrutura abaixo
3. Guardar em `Concursos/<nome>/analise-go-no-go.md`

## Estrutura obrigatória
```
# Análise Go/No-Go — <Concurso>

## 1. Ficha do concurso (preço base, prazo execução, prazo proposta, critério)
## 2. Conseguimos cumprir os requisitos? (alvará, certificações, capacidade)
## 3. Riscos principais (máximo 5, por ordem de gravidade, cada um com mitigação)
## 4. Análise competitiva (quem deve concorrer, histórico, como nos posicionamos)
## 5. Encaixe na carteira (capacidade disponível vs. prazo de execução)
## 6. RECOMENDAÇÃO: Avançar / Não avançar / Avançar com reservas — e porquê em 3 frases
```

## Regras
- A recomendação nunca fica em cima do muro — escolher uma das três opções
- Cláusulas perigosas (multas diárias, condições de execução invulgares, prazos de pagamento longos) entram sempre nos riscos
- Verificar sempre o prazo de entrega da proposta contra a data de hoje — se faltar pouco tempo, isso é o primeiro risco
- Usar o histórico comercial interno se existir nas notas (relação com a entidade, concorrentes conhecidos)
