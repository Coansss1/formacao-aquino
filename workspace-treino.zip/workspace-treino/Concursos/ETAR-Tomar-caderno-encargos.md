# Concurso Público — Remodelação da ETAR de Tomar
*(dados fictícios para demonstração — resumo do caderno de encargos, como se tivesse sido extraído do anúncio no base.gov.pt)*

## Dados do procedimento
- **Entidade adjudicante:** Município de Tomar
- **Procedimento:** Concurso público (CCP)
- **Objeto:** Remodelação e ampliação da ETAR de Tomar — obras de construção civil, instalações elétricas e equipamento eletromecânico
- **Preço base:** €2.480.000 + IVA
- **Prazo de execução:** 540 dias
- **Prazo de entrega de propostas:** 2026-08-04, 17h00
- **Critério de adjudicação:** melhor relação qualidade-preço — preço 60%, valia técnica 25%, prazo 15%
- **Caução:** 5% do valor de adjudicação

## Requisitos de habilitação
- Alvará de empreiteiro classe 5 ou superior
- Subcategoria 1ª da 2ª categoria (redes de saneamento) — obrigatória
- Certificação ISO 9001 e ISO 14001 valorizada na valia técnica

## Condições relevantes
- Obra a executar **com a ETAR em funcionamento** — faseamento obrigatório, sem interrupção do tratamento
- Multa contratual por atraso: €2.500/dia
- Pagamentos: autos de medição mensais, prazo de pagamento 60 dias
- Revisão de preços: fórmula tipo, conforme decreto em vigor
- Visita ao local: obrigatória, até 10 dias antes do prazo de entrega
- Plano de gestão ambiental exigido (proximidade do rio Nabão)

## Notas comerciais internas
- Ganhámos 2 obras de saneamento para este município (2021, 2023) — boa relação com os serviços técnicos
- Concorrentes prováveis: Hidroconstrói (ganhou as últimas 2 ETARs na região, agressiva no preço), Construtora do Zêzere (local, mais fraca em eletromecânica)
- A nossa carteira atual: 78% da capacidade ocupada até março de 2027
