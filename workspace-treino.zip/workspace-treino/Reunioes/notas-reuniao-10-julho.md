# Notas soltas — reunião de produção, 10 julho 2026
*(dados fictícios para demonstração — notas tal como alguém as escreveu durante a reunião)*

presentes: Sandra S, Bryan, Luis V, Carlos P, Rita

quinta das oliveiras lote 3 - betonagens ok mas betão centro voltou a atrasar, bryan diz que é a 3a vez este mês. ver alternativas de fornecedor -> compras
lote 3: visita dono de obra dia 17, sandra prepara dossier
ETAR tomar: luis v está a analisar o caderno de encargos, decisão go/no-go na próxima reunião. carlos lembra que a hidroconstroi deve concorrer
obra do algarve (hotel praia verde): auto de medição de junho ainda não foi submetido!! rita trata disso esta semana, o atraso já custou juros no mês passado
equipamentos: a grua 2 precisa de inspeção periódica até fim do mês, agendar
QAS: 2 quase-acidentes na quinta das oliveiras este mês (queda de material). sandra coelho vai fazer ação de sensibilização na obra, data a definir
férias de agosto: mapa de férias tem 3 conflitos na equipa de produção, sandy resolve com os chefes de equipa até dia 20
próxima reunião: 24 julho 9h30
