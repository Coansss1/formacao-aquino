# Cotações — Fornecimento de betão C30/37, Obra Quinta das Oliveiras
*(dados fictícios para demonstração — 3 cotações recebidas por email, coladas aqui tal como chegaram)*

---

**Email 1 — Betão Centro, Lda (recebido 10/07)**
Exmos senhores, na sequência do vosso pedido cotamos: betão C30/37 XC4 a 94,50€/m3 para as quantidades indicadas (estimativa 850 m3 até dezembro). Transporte incluído até 25km. Bombagem: 8€/m3. Condições: 30 dias. Fornecimento em 48h após pedido. Cumprimentos, Manuel Andrade

---

**Email 2 — Cimentados do Oeste SA (recebido 11/07)**
Boa tarde, segue proposta: C30/37 XC4 — 91,00€/m3, volume mínimo por carga 7m3. Bombagem incluída para betonagens acima de 40m3, caso contrário 10€/m3. Transporte: 2,5€/m3 acima de 15km (a vossa obra fica a 32km da nossa central). Pagamento: 50% a 30 dias, 50% a 60 dias. Nota: agosto temos paragem de manutenção da central de dia 10 a 21. Melhores cumprimentos, Eng. Paula Simões

---

**Email 3 — Betominho (recebido 14/07)**
Srs, C30/37 a 88€/m3 tudo incluído (transporte e bombagem) para compromisso mínimo de 600 m3. Pagamento a pronto com desconto adicional de 2%, ou 30 dias sem desconto. Prazo de fornecimento: 72h após encomenda. Obs: a nossa central de Leiria está no limite da capacidade — em semanas de pico o prazo pode ir a 5 dias úteis. Cumprimentos, José Minhoto

---

*Contexto da obra: betonagens semanais de 30-60 m3 entre julho e dezembro, total estimado 850 m3. Atrasos de betão já custaram 2 paragens este mês (fornecedor atual: Betão Centro). A betonagem crítica da zona C é já dia 17/07.*
