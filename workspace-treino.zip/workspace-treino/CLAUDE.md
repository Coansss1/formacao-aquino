# CLAUDE.md — Aquino Construções (Workspace de Demonstração)

*Este workspace é o exemplo usado na formação de IA. Todos os dados são fictícios mas realistas. Serve para mostrar como uma construtora pode organizar o seu trabalho com o Claude.*

---

## 1. Quem somos

**Aquino Construções, S.A.** — construtora fundada em 1977, sede em Ourém.
~150 colaboradores. Obra pública (infraestruturas de água e saneamento, requalificação urbana) e obra particular (residencial, comercial). Mais de 1.600 projetos concluídos.

**Quem usa este workspace:** a equipa de coordenação — produção, orçamentação, compras, QAS e administração.

## 2. Como está organizado

```
Obras/        — uma pasta por obra ativa. Diários de obra, relatórios, ocorrências.
Concursos/    — concursos públicos em análise. Cadernos de encargos, análises, decisões.
Compras/      — cotações de fornecedores e comparações.
Reunioes/     — notas de reuniões e atas.
```

## 3. Regras de trabalho com o Claude

- **Língua:** tudo em português europeu.
- **Relatórios de obra:** seguem sempre o modelo definido no skill `relatorio-obra`. Linguagem técnica, secções numeradas.
- **Análises de concursos:** terminam sempre com uma recomendação clara (avançar / não avançar / avançar com reservas) e os 3 riscos principais.
- **Comparações de cotações:** apresentar sempre em tabela, com preço total, prazos, condições de pagamento e uma recomendação fundamentada.
- **Atas:** identificar sempre os responsáveis por cada ação e o prazo. Uma ação sem responsável não é uma ação.
- **Nunca inventar valores.** Se um dado não está nos ficheiros, perguntar ou assinalar como em falta.
- **Confidencialidade:** este workspace contém informação da empresa. Não usar dados daqui em contextos externos.

## 4. Skills disponíveis (construídos na formação)

| Skill | O que faz |
|---|---|
| `relatorio-obra` | Transforma as notas rápidas do encarregado num relatório diário formal |
| `analise-concurso` | Analisa um caderno de encargos e produz uma recomendação go/no-go |
| `compara-cotacoes` | Compara cotações de fornecedores e recomenda |
| `ata-reuniao` | Transforma notas soltas de reunião numa ata com ações e responsáveis |
